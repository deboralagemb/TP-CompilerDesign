let _ = print_string "Digite o primeiro numero\n";;
let firstNumber = read_int();;
let _ = print_string "Digite o segundo numero\n";;
let secondNumber = read_int();;
let sum = firstNumber + secondNumber;;
let () = Printf.printf "A soma dos dois inteiros eh: %d \n" sum;;
